<?php
require_once "conexion.php";
$id = intval($_GET["id"] ?? 0);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $sql = "UPDATE pacientes SET nombre=?, apellido=?, fecha_nacimiento=?, sexo=?, telefono=?, correo=?, tipo_sangre=?, alergias=?, antecedentes=?, diagnostico=?, tratamiento=?, observaciones=?, fecha_consulta=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssssi",
        $_POST["nombre"], $_POST["apellido"], $_POST["fecha_nacimiento"], $_POST["sexo"],
        $_POST["telefono"], $_POST["correo"], $_POST["tipo_sangre"], $_POST["alergias"],
        $_POST["antecedentes"], $_POST["diagnostico"], $_POST["tratamiento"],
        $_POST["observaciones"], $_POST["fecha_consulta"], $id
    );
    $stmt->execute();
    header("Location: pacientes.php?actualizado=1");
    exit;
}

$stmt = $conn->prepare("SELECT * FROM pacientes WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();
if (!$p) die("Paciente no encontrado.");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Editar paciente</title><link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<header class="topbar">
<div><strong>🏥 Registros Médicos</strong><span>Editar expediente</span></div>
<nav><a href="index.php">Inicio</a><a href="registrar.php">Registrar</a><a href="pacientes.php">Pacientes</a></nav>
</header>
<main class="container">
<div class="page-title"><h1>Editar paciente</h1><p>Modifica la información del expediente.</p></div>
<form method="POST" class="form-card">
<h2>👤 Datos personales</h2>
<div class="grid">
<label>Nombre<input type="text" name="nombre" required value="<?= htmlspecialchars($p["nombre"]) ?>"></label>
<label>Apellido<input type="text" name="apellido" required value="<?= htmlspecialchars($p["apellido"]) ?>"></label>
<label>Fecha de nacimiento<input type="date" name="fecha_nacimiento" required value="<?= htmlspecialchars($p["fecha_nacimiento"]) ?>"></label>
<label>Sexo<select name="sexo"><?php foreach(["","Femenino","Masculino","Otro"] as $x): ?><option <?= $p["sexo"]===$x?"selected":"" ?>><?= $x ?></option><?php endforeach; ?></select></label>
<label>Teléfono<input type="text" name="telefono" value="<?= htmlspecialchars($p["telefono"]) ?>"></label>
<label>Correo<input type="email" name="correo" value="<?= htmlspecialchars($p["correo"]) ?>"></label>
<label>Tipo de sangre<input type="text" name="tipo_sangre" value="<?= htmlspecialchars($p["tipo_sangre"]) ?>"></label>
</div>
<h2>🩺 Información médica</h2>
<div class="grid">
<label>Alergias<textarea name="alergias"><?= htmlspecialchars($p["alergias"]) ?></textarea></label>
<label>Antecedentes<textarea name="antecedentes"><?= htmlspecialchars($p["antecedentes"]) ?></textarea></label>
<label>Diagnóstico<textarea name="diagnostico"><?= htmlspecialchars($p["diagnostico"]) ?></textarea></label>
<label>Tratamiento<textarea name="tratamiento"><?= htmlspecialchars($p["tratamiento"]) ?></textarea></label>
<label>Observaciones<textarea name="observaciones"><?= htmlspecialchars($p["observaciones"]) ?></textarea></label>
<label>Fecha de consulta<input type="date" name="fecha_consulta" value="<?= htmlspecialchars($p["fecha_consulta"]) ?>"></label>
</div>
<div class="form-actions"><a class="btn secondary" href="pacientes.php">Cancelar</a><button class="btn primary">Guardar cambios</button></div>
</form>
</main>
<footer>Registros Médicos · Proyecto académico</footer>
</body>
</html>