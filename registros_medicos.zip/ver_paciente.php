<?php
require_once "conexion.php";
$id = intval($_GET["id"] ?? 0);
$stmt = $conn->prepare("SELECT * FROM pacientes WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$p = $stmt->get_result()->fetch_assoc();
if (!$p) die("Paciente no encontrado.");
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Expediente médico</title>
<link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<header class="topbar">
<div><strong>🏥 Registros Médicos</strong><span>Expediente médico</span></div>
<nav><a href="index.php">Inicio</a><a href="registrar.php">Registrar</a><a href="pacientes.php">Pacientes</a></nav>
</header>

<main class="container">
<div class="page-title row"><div><h1>Expediente médico</h1><p>Información completa del paciente.</p></div>
<div><a class="btn secondary" href="pacientes.php">← Regresar</a> <a class="btn primary" href="editar.php?id=<?= $p["id"] ?>">Editar</a></div></div>

<section class="profile">
<div class="avatar">👤</div>
<div><h2><?= htmlspecialchars($p["nombre"] . " " . $p["apellido"]) ?></h2><p>Paciente #<?= $p["id"] ?> · Tipo de sangre: <?= htmlspecialchars($p["tipo_sangre"] ?: "No especificado") ?></p></div>
</section>

<div class="detail-grid">
<div class="detail-card"><h3>Datos personales</h3>
<p><b>Fecha de nacimiento:</b> <?= htmlspecialchars($p["fecha_nacimiento"]) ?></p>
<p><b>Sexo:</b> <?= htmlspecialchars($p["sexo"] ?: "No especificado") ?></p>
<p><b>Teléfono:</b> <?= htmlspecialchars($p["telefono"] ?: "No especificado") ?></p>
<p><b>Correo:</b> <?= htmlspecialchars($p["correo"] ?: "No especificado") ?></p>
</div>
<div class="detail-card"><h3>Consulta médica</h3>
<p><b>Fecha:</b> <?= htmlspecialchars($p["fecha_consulta"] ?: "No especificada") ?></p>
<p><b>Diagnóstico:</b> <?= nl2br(htmlspecialchars($p["diagnostico"] ?: "Sin información")) ?></p>
<p><b>Tratamiento:</b> <?= nl2br(htmlspecialchars($p["tratamiento"] ?: "Sin información")) ?></p>
</div>
<div class="detail-card"><h3>Antecedentes y alergias</h3>
<p><b>Alergias:</b><br><?= nl2br(htmlspecialchars($p["alergias"] ?: "Ninguna registrada")) ?></p>
<p><b>Antecedentes:</b><br><?= nl2br(htmlspecialchars($p["antecedentes"] ?: "Ninguno registrado")) ?></p>
</div>
<div class="detail-card"><h3>Observaciones</h3>
<p><?= nl2br(htmlspecialchars($p["observaciones"] ?: "Sin observaciones.")) ?></p>
</div>
</div>
</main>
<footer>Registros Médicos · Proyecto académico</footer>
</body>
</html>