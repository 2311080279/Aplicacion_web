<?php
require_once "conexion.php";
$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $sql = "INSERT INTO pacientes
    (nombre, apellido, fecha_nacimiento, sexo, telefono, correo, tipo_sangre,
     alergias, antecedentes, diagnostico, tratamiento, observaciones, fecha_consulta)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssssssssssss",
        $_POST["nombre"], $_POST["apellido"], $_POST["fecha_nacimiento"],
        $_POST["sexo"], $_POST["telefono"], $_POST["correo"], $_POST["tipo_sangre"],
        $_POST["alergias"], $_POST["antecedentes"], $_POST["diagnostico"],
        $_POST["tratamiento"], $_POST["observaciones"], $_POST["fecha_consulta"]
    );

    if ($stmt->execute()) {
        header("Location: pacientes.php?registrado=1");
        exit;
    } else {
        $mensaje = "No se pudo registrar el paciente.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registrar paciente</title>
<link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<header class="topbar">
<div><strong>🏥 Registros Médicos</strong><span>Nuevo expediente</span></div>
<nav><a href="index.php">Inicio</a><a href="registrar.php">Registrar</a><a href="pacientes.php">Pacientes</a></nav>
</header>

<main class="container">
<div class="page-title"><h1>Registrar paciente</h1><p>Completa los datos personales y médicos.</p></div>

<?php if ($mensaje): ?><div class="alert error"><?= htmlspecialchars($mensaje) ?></div><?php endif; ?>

<form method="POST" class="form-card">
<h2>👤 Datos personales</h2>
<div class="grid">
<label>Nombre<input type="text" name="nombre" required></label>
<label>Apellido<input type="text" name="apellido" required></label>
<label>Fecha de nacimiento<input type="date" name="fecha_nacimiento" required></label>
<label>Sexo
<select name="sexo"><option value="">Seleccionar</option><option>Femenino</option><option>Masculino</option><option>Otro</option></select>
</label>
<label>Teléfono<input type="text" name="telefono"></label>
<label>Correo electrónico<input type="email" name="correo"></label>
<label>Tipo de sangre
<select name="tipo_sangre">
<option value="">Seleccionar</option><option>A+</option><option>A-</option><option>B+</option><option>B-</option><option>AB+</option><option>AB-</option><option>O+</option><option>O-</option>
</select>
</label>
</div>

<h2>🩺 Información médica</h2>
<div class="grid">
<label>Alergias<textarea name="alergias"></textarea></label>
<label>Antecedentes médicos<textarea name="antecedentes"></textarea></label>
<label>Diagnóstico<textarea name="diagnostico"></textarea></label>
<label>Tratamiento<textarea name="tratamiento"></textarea></label>
<label>Observaciones<textarea name="observaciones"></textarea></label>
<label>Fecha de consulta<input type="date" name="fecha_consulta" value="<?= date('Y-m-d') ?>"></label>
</div>

<div class="form-actions">
<a class="btn secondary" href="pacientes.php">Cancelar</a>
<button class="btn primary" type="submit">Guardar paciente</button>
</div>
</form>
</main>
<footer>Registros Médicos · Proyecto académico</footer>
</body>
</html>