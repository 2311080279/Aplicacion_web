CREATE DATABASE IF NOT EXISTS registros_medicos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE registros_medicos;

CREATE TABLE IF NOT EXISTS pacientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    sexo VARCHAR(20),
    telefono VARCHAR(20),
    correo VARCHAR(100),
    tipo_sangre VARCHAR(10),
    alergias TEXT,
    antecedentes TEXT,
    diagnostico TEXT,
    tratamiento TEXT,
    observaciones TEXT,
    fecha_consulta DATE
);

INSERT INTO pacientes
(nombre, apellido, fecha_nacimiento, sexo, telefono, correo, tipo_sangre, alergias, antecedentes, diagnostico, tratamiento, observaciones, fecha_consulta)
VALUES
('Juan', 'Pérez', '1998-05-12', 'Masculino', '2221234567', 'juan@example.com', 'O+',
 'Penicilina', 'Asma infantil', 'Gastritis', 'Medicamento indicado por el médico',
 'Paciente estable.', CURDATE());