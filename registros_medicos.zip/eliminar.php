<?php
require_once "conexion.php";
$id = intval($_GET["id"] ?? 0);

if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM pacientes WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}
header("Location: pacientes.php?eliminado=1");
exit;
?>