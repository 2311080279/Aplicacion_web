<?php
require_once "conexion.php";
$busqueda = trim($_GET["buscar"] ?? "");

if ($busqueda !== "") {
    $like = "%" . $busqueda . "%";
    $stmt = $conn->prepare("SELECT * FROM pacientes WHERE nombre LIKE ? OR apellido LIKE ? OR diagnostico LIKE ? ORDER BY id DESC");
    $stmt->bind_param("sss", $like, $like, $like);
    $stmt->execute();
    $resultado = $stmt->get_result();
} else {
    $resultado = $conn->query("SELECT * FROM pacientes ORDER BY id DESC");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pacientes</title>
<link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<header class="topbar">
<div><strong>🏥 Registros Médicos</strong><span>Pacientes registrados</span></div>
<nav><a href="index.php">Inicio</a><a href="registrar.php">Registrar</a><a href="pacientes.php">Pacientes</a></nav>
</header>

<main class="container">
<div class="page-title row"><div><h1>Pacientes registrados</h1><p>Consulta los expedientes almacenados.</p></div><a class="btn primary" href="registrar.php">+ Nuevo paciente</a></div>

<?php if (isset($_GET["registrado"])): ?><div class="alert success">✓ Paciente registrado correctamente.</div><?php endif; ?>
<?php if (isset($_GET["actualizado"])): ?><div class="alert success">✓ Paciente actualizado correctamente.</div><?php endif; ?>
<?php if (isset($_GET["eliminado"])): ?><div class="alert success">✓ Paciente eliminado correctamente.</div><?php endif; ?>

<form class="search" method="GET">
<input type="text" name="buscar" placeholder="Buscar por nombre, apellido o diagnóstico..." value="<?= htmlspecialchars($busqueda) ?>">
<button class="btn primary" type="submit">Buscar</button>
<a class="btn secondary" href="pacientes.php">Limpiar</a>
</form>

<div class="table-card">
<table>
<thead><tr><th>ID</th><th>Paciente</th><th>Fecha nacimiento</th><th>Tipo sangre</th><th>Diagnóstico</th><th>Acciones</th></tr></thead>
<tbody>
<?php if ($resultado->num_rows > 0): ?>
<?php while ($p = $resultado->fetch_assoc()): ?>
<tr>
<td><?= $p["id"] ?></td>
<td><strong><?= htmlspecialchars($p["nombre"] . " " . $p["apellido"]) ?></strong></td>
<td><?= htmlspecialchars($p["fecha_nacimiento"]) ?></td>
<td><?= htmlspecialchars($p["tipo_sangre"] ?: "—") ?></td>
<td><?= htmlspecialchars($p["diagnostico"] ?: "Sin diagnóstico") ?></td>
<td class="actions-cell">
<a href="ver_paciente.php?id=<?= $p["id"] ?>">Ver</a>
<a href="editar.php?id=<?= $p["id"] ?>">Editar</a>
<a class="danger-link" href="eliminar.php?id=<?= $p["id"] ?>" onclick="return confirm('¿Eliminar este paciente?')">Eliminar</a>
</td>
</tr>
<?php endwhile; ?>
<?php else: ?><tr><td colspan="6" class="empty">No hay pacientes registrados.</td></tr><?php endif; ?>
</tbody>
</table>
</div>
</main>
<footer>Registros Médicos · Proyecto académico</footer>
</body>
</html>