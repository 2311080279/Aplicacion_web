<?php require_once "conexion.php"; ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Registros Médicos</title>
<link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<header class="topbar">
    <div><strong>🏥 Registros Médicos</strong><span>Sistema de expedientes médicos</span></div>
    <nav><a href="index.php">Inicio</a><a href="registrar.php">Registrar</a><a href="pacientes.php">Pacientes</a></nav>
</header>

<main class="container">
<section class="hero">
    <div>
        <span class="badge">SISTEMA MÉDICO</span>
        <h1>Control sencillo de expedientes médicos</h1>
        <p>Registra, consulta y administra la información de tus pacientes desde una interfaz sencilla.</p>
        <div class="actions">
            <a class="btn primary" href="registrar.php">+ Registrar paciente</a>
            <a class="btn secondary" href="pacientes.php">Ver pacientes</a>
        </div>
    </div>
    <div class="hero-icon">🩺</div>
</section>

<div class="cards">
    <div class="card"><div class="icon">👤</div><h3>Pacientes</h3><p>Registra datos personales y de contacto.</p></div>
    <div class="card"><div class="icon">📋</div><h3>Expedientes</h3><p>Consulta diagnóstico, tratamiento y antecedentes.</p></div>
    <div class="card"><div class="icon">🗄️</div><h3>Base de datos</h3><p>Información organizada en MariaDB/MySQL.</p></div>
</div>
</main>
<footer>Registros Médicos · Proyecto académico</footer>
</body>
</html>